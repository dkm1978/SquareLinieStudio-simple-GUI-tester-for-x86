import os
Import("env", "projenv")
from pathlib import Path


def post_program_action(source, target, env): 
    
    if os.path.exists("binary")==False:os.mkdir("binary", 0o666)
    objdump="@copy "
    src_elf=env.subst("\"${BUILD_DIR}\\${PROGNAME}.exe\"")
    new_name=os.path.basename(os.path.normpath(env.subst('${PROJECT_DIR}')))
    print(new_name)
    cmd=" ".join([objdump,src_elf,"\"${PROJECT_DIR}\\binary\\",new_name,".exe\" > nul"])  
    env.Execute(cmd)
    objdump="@del "
    src_elf=env.subst("\"${BUILD_DIR}\\${PROGNAME}.exe\"")
    cmd=" ".join([objdump,src_elf])  
    env.Execute(cmd)
    objdump="@"
    cmd=" ".join([objdump,"\"${PROJECT_DIR}\\binary\\",new_name,".exe\""])  
    env.Execute(cmd)
  
    


env.AddPostAction("$BUILD_DIR/program.exe", post_program_action)